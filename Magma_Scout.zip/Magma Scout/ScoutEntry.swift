//
//  ScoutEntry.swift
//  Magma Scout
//
//  Created by David Bauducco on 5/7/18.
//  Copyright © 2018 Magma Robotics. All rights reserved.
//

import Foundation
import CoreData

@objc(ScoutEntry)
public class ScoutEntry: NSManagedObject
{
    // General Date
    @NSManaged var matchId: String
    @NSManaged var teamNumber: String
    
    // Match Specific Data
    @NSManaged var vaultCount: Int16
    @NSManaged var scaleCount: Int16
    @NSManaged var switchCount: Int16
    @NSManaged var opponentSwitchCount: Int16
    
    @NSManaged var didClimb: Bool
    @NSManaged var didAuto: Bool
    
    convenience init ()
    {
        self.init()
        
        self.matchId = "0000"
        self.teamNumber = "0000"
        
        self.vaultCount = 0
        self.scaleCount = 0
        self.switchCount = 0
        self.opponentSwitchCount = 0
        self.didClimb = false
        self.didAuto = false
    }
    
    convenience init(matchId: String, teamNumber: String, vaultCount: Int16, scaleCount: Int16, switchCount: Int16, opponentSwitchCount: Int16, didClimb: Bool, didAuto: Bool)
    {
        
        self.init()
        
        self.matchId = matchId
        self.teamNumber = teamNumber
        
        self.vaultCount = vaultCount
        self.scaleCount = scaleCount
        self.switchCount = switchCount
        self.opponentSwitchCount = opponentSwitchCount
        self.didClimb = didClimb
        self.didAuto = didAuto
        
    }
}

