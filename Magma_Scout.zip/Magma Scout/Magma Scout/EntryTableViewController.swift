//
//  EntryTableViewController.swift
//  Magma Scout
//
//  Created by David Bauducco on 5/10/18.
//  Copyright © 2018 Magma Robotics. All rights reserved.
//

import UIKit
import Foundation
import CoreData

class EntryTableViewController: UITableViewController {

    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var entry: ScoutEntry?
    var displays0 = [String]()
    var displays1 = [String]()
    var displays2 = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.displays0 = []
        self.displays1 = []
        self.displays2 = []
        
        let managedContext = appDelegate.managedContext
        managedContext?.refresh(entry!, mergeChanges: true)
        
        self.displays0.append("Team Number: \(entry?.teamNumber ?? "--")")
        self.displays0.append("Match ID: \(entry?.matchId ?? "--")")
        
        self.displays1.append("Vault Count: \(entry?.vaultCount ?? 0)")
        self.displays1.append("Scale Count: \(entry?.scaleCount ?? 0)")
        self.displays1.append("Switch Count: \(entry?.switchCount ?? 0)")
        self.displays1.append("Opponen Switch Count: \(entry?.opponentSwitchCount ?? 0)")
        
        self.displays2.append("Did perform auto: \(entry?.didAuto ?? false)")
        self.displays2.append("Did climb: \(entry?.didClimb ?? false)")
        
        self.tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 3
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if (section == 0) {
            return displays0.count
        } else if (section == 1) {
            return displays1.count
        } else if (section == 2) {
            return displays2.count
        }
        
        return 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "EntryCell")
        
        if (indexPath.section == 0) {
            cell.textLabel?.text = displays0[indexPath.row]
        } else if (indexPath.section == 1) {
            cell.textLabel?.text = displays1[indexPath.row]
        } else if (indexPath.section == 2) {
            cell.textLabel?.text = displays2[indexPath.row]
        }
        
        return cell
    }
    
    @IBAction func editClicked(_ sender: Any) {
        self.performSegue(withIdentifier: "editEntry", sender: nil)
    }
    
    @IBAction func unwindToEntryScreen(segue:UIStoryboardSegue) { }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "editEntry")
        {
            let dest = (segue.destination as! UINavigationController).topViewController as! EntryEditorTableViewController
            
            dest.entry = entry!
        }
    }


}

