//
//  EntryEditorTableViewController.swift
//  Magma Scout
//
//  Created by David Bauducco on 5/10/18.
//  Copyright © 2018 Magma Robotics. All rights reserved.
//

import UIKit

class EntryEditorTableViewController: UITableViewController {

    var entry: ScoutEntry?
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var stepperLabel: UILabel!
    @IBOutlet weak var stepper2Label: UILabel!
    @IBOutlet weak var stepper3Label: UILabel!
    @IBOutlet weak var stepper4Label: UILabel!
    
    @IBOutlet weak var stepper1: UIStepper!
    @IBOutlet weak var stepper2: UIStepper!
    @IBOutlet weak var stepper3: UIStepper!
    @IBOutlet weak var stepper4: UIStepper!
    
    var vaultCount = 0
    var scaleCount = 0
    var switchCount = 0
    var opponentSwitchCount = 0
    
    @IBOutlet weak var teamNumberEntry: UITextField!
    @IBOutlet weak var matchIdEntry: UITextField!
    
    @IBOutlet weak var autoSwitch: UISwitch!
    @IBOutlet weak var climbSwitch: UISwitch!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        teamNumberEntry.text = entry?.teamNumber ?? ""
        matchIdEntry.text = entry?.matchId ?? ""
        
        vaultCount = Int(entry?.vaultCount ?? 0)
        stepper1.value = Double(vaultCount)
        stepperLabel.text = "\(vaultCount)"
        scaleCount = Int(entry?.scaleCount ?? 0)
        stepper2.value = Double(scaleCount)
        stepper2Label.text = "\(scaleCount)"
        switchCount = Int(entry?.switchCount ?? 0)
        stepper3.value = Double(switchCount)
        stepper3Label.text = "\(switchCount)"
        opponentSwitchCount = Int(entry?.opponentSwitchCount ?? 0)
        stepper4.value = Double(opponentSwitchCount)
        stepper4Label.text = "\(opponentSwitchCount)"
        
        autoSwitch.isOn = entry?.didAuto ?? false
        climbSwitch.isOn = entry?.didClimb ?? false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func stepperClicked(_ sender: UIStepper) {
        stepperLabel.text = "\(Int(sender.value))"
        vaultCount = Int(sender.value)
    }
    
    @IBAction func stepper2Clicked(_ sender: UIStepper) {
        stepper2Label.text = "\(Int(sender.value))"
        scaleCount = Int(sender.value)
    }
    
    @IBAction func stepper3Clicked(_ sender: UIStepper) {
         stepper3Label.text = "\(Int(sender.value))"
         switchCount = Int(sender.value)
    }
    
    @IBAction func stepper4Clicked(_ sender: UIStepper) {
         stepper4Label.text = "\(Int(sender.value))"
         opponentSwitchCount = Int(sender.value)
    }
    
    @IBAction func cancelClicked(_ sender: Any) {
        let managedContext = appDelegate.managedContext!
       
        do {
            try managedContext.save()
        } catch {}
        
        self.performSegue(withIdentifier: "goToUnwind", sender: nil)
    }
    
    @IBAction func doneClicked(_ sender: Any) {
        
        let managedContext = appDelegate.managedContext
        
        entry?.teamNumber = teamNumberEntry.text!
        entry?.matchId = matchIdEntry.text!
        
        entry?.vaultCount = Int16(vaultCount)
        entry?.scaleCount = Int16(scaleCount)
        entry?.switchCount = Int16(switchCount)
        entry?.opponentSwitchCount = Int16(opponentSwitchCount)
        
        entry?.didAuto = autoSwitch.isOn
        entry?.didClimb = climbSwitch.isOn
        
        do
        {
            try managedContext?.save()
        } catch {
        }
        
        self.performSegue(withIdentifier: "goToUnwind", sender: nil)
    }
    
}
