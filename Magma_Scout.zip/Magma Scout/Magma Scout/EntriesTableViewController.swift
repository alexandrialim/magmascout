//
//  EntriesTableViewController.swift
//  Magma Scout
//
//  Created by David Bauducco on 5/10/18.
//  Copyright © 2018 Magma Robotics. All rights reserved.
//

import UIKit
import CoreData
import Foundation

class EntriesTableViewController: UITableViewController {

    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var entries = [ScoutEntry]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.refresh()
        self.tableView.reloadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.refresh()
        self.tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
 
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return entries.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "EntryCell")
        cell.textLabel?.text = entries[indexPath.row].teamNumber
        cell.detailTextLabel?.text = entries[indexPath.row].matchId

        return cell
    }
 
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "goToEntry", sender: self)
    }
    
    public func refresh() {
        
        let managedContext = appDelegate.managedContext!
        entries = []
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "ScoutEntry")
        
        do {
            entries = try managedContext.fetch(fetchRequest) as! [ScoutEntry]
        } catch {
            print(error)
        }
    }

    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.delete)
        {
            let managedContext = appDelegate.managedContext!
            managedContext.delete(entries[indexPath.row])
            
            do {
                try managedContext.save()
            } catch {}
            
            entries.remove(at: indexPath.row)
            entries = []
            self.refresh()
            self.tableView.reloadData()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "goToEntry")
        {
            let dest = segue.destination as! EntryTableViewController
            dest.entry = entries[(self.tableView.indexPathForSelectedRow?.row)!]
        } else if (segue.identifier == "createNewEntry")
        {
            let dest = (segue.destination as! UINavigationController).topViewController as! EntryEditorTableViewController
            let managedContext = appDelegate.managedContext!
            let entity = NSEntityDescription.entity(forEntityName: "ScoutEntry", in: managedContext)!
            
            dest.entry = ScoutEntry(entity: entity, insertInto: managedContext)
        }
    }

    @IBAction func createNewEntry(_ sender: Any) {
        self.performSegue(withIdentifier: "createNewEntry", sender: nil)
    }
    
    @IBAction func unwindToEntryScreen(segue:UIStoryboardSegue) { }
}
