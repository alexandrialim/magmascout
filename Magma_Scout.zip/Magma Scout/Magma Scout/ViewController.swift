//
//  ViewController.swift
//  Magma Scout
//
//  Created by David Bauducco on 5/7/18.
//  Copyright © 2018 Magma Robotics. All rights reserved.
//

import UIKit
import Foundation
import CoreData

class ViewController: UIViewController {

    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var entries = [ScoutEntry]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let managedContext = appDelegate.managedContext!
        
        let entity = NSEntityDescription.entity(forEntityName: "ScoutEntry", in: managedContext)!
        
        let newEntry = ScoutEntry(entity: entity, insertInto: managedContext)
        newEntry.didAuto = false
        
        
        managedContext.reset()
        
        do {
            try managedContext.save()
        } catch {
            print(error)
        }
        
        refresh()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        refresh()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    public func refresh() {
        
        let managedContext = appDelegate.managedContext!
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "ScoutEntry")
        
        do {
            entries = try managedContext.fetch(fetchRequest) as! [ScoutEntry]
            print(entries[0].didAuto)
        } catch {
            print(error)
        }
    }

}

